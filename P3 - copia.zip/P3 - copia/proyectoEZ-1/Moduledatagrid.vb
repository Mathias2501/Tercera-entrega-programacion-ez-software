﻿Imports MySql.Data.MySqlClient
Module Moduledatagrid
    Dim conexion As New MySqlConnection
    Dim cmd As New MySqlCommand
    Sub datagrid()
        Try

            conexion = New MySqlConnection("server=localhost; database=mercado_lider;Uid=root;Pwd=;")
            conexion.Open()
        Catch ex As Exception
            MsgBox("no se pudo conectar" + ex.ToString)
        End Try
    End Sub

    Public Function llenardatagrid(ByVal dg As DataGridView, ByVal sql As String)
        Try
            cmd.CommandText = sql
            cmd.Connection = conexion
            Dim dj As MySqlDataReader
            Dim dt As New DataTable

            dj = cmd.ExecuteReader
            dt.Load(dj)
            dg.DataSource = dt
            dj.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Function
End Module
