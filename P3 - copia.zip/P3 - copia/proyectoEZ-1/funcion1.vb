﻿Imports MySql.Data.MySqlClient
Module funcion1
    Public email As String
    Public idusu1 As String
End Module
