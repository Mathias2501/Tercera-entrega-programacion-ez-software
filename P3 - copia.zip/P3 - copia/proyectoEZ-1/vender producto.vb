﻿Imports MySql.Data.MySqlClient
Public Class formvenderproducto
    Dim imgbyte As Byte() = Nothing
    Dim conexion As New MySqlConnection
    Dim cmd As New MySqlCommand
    Dim datos As DataSet
    Dim ada As MySqlDataAdapter
    Private Sub Buttonvender_Click(sender As Object, e As EventArgs) Handles Buttonvender.Click
        conexion.ConnectionString = "server=localhost; database=mercado_lider;Uid=root;Pwd=;"
        If txtnombreproducto.Text = "" Or txtprecio.Text = "" Or txtdescripcion.Text = "" Or txtcantidad.Text = "" Then
            MsgBox("ingrese todos los datos")
        Else
            Try
                If txtnombreproducto.Text <> String.Empty Or txtprecio.Text <> String.Empty Or txtdescripcion.Text <> String.Empty Or txtcantidad.Text <> String.Empty Then
                    conexion.Open()
                    cmd.Connection = conexion
                    cmd.CommandText = "INSERT INTO productos(ID_producto,nombre_producto,precio,descripcion,stock,id_usuario) values ('null','@nombreproducto','@precio','@descripsion','@stock','@idusu')"
                    cmd.Prepare()
                    cmd.Parameters.AddWithValue("@nombreproducto", txtnombreproducto.Text)
                    cmd.Parameters.AddWithValue("@precio", txtprecio.Text)
                    cmd.Parameters.AddWithValue("@descripsion", txtdescripcion.Text)
                    cmd.Parameters.AddWithValue("@stock", txtcantidad.Text)
                    cmd.Parameters.AddWithValue("@idusu", txtidusu.Text)
                    cmd.ExecuteNonQuery()
                End If
                conexion.Close()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
        datagrid()
        Dim sql2 As String
        sql2 = "SELECT nombre_producto,stock,descripcion,precio FROM productos"
        llenardatagrid(txtdatagrid, sql2)
    End Sub

    Private Sub formvenderproducto_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        datagrid()
        Dim sql2 As String
        sql2 = "SELECT nombre_producto,stock,descripcion,precio FROM productos"
        llenardatagrid(txtdatagrid, sql2)
        txtidusu.Text = funcion1.email
        Dim idusu As Integer = txtidusu.Text
        Try
            conexion.ConnectionString = "server=localhost; database=mercado_lider;Uid=root;Pwd=;"
            conexion.Open()
            Dim consulta As String
            consulta = "select * from categoria"
            ada = New MySqlDataAdapter(consulta, conexion)
            datos = New DataSet
            datos.Tables.Add("categoria")
            ada.Fill(datos.Tables("categoria"))
            txtComBox.DataSource = datos.Tables("categoria")
            txtComBox.DisplayMember = "nombre_categoria"
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            conexion.Close()
        End Try
    End Sub

    Private Sub Buttonatras_Click(sender As Object, e As EventArgs) Handles Buttonatras.Click
        Forminiciosesion.Show()
        Me.Hide()
    End Sub

    Private Sub txtbuscar_Click(sender As Object, e As EventArgs) Handles txtbuscar.Click
        If OpenFileDialog1.ShowDialog = vbOK Then
            Dim myimagen As Image = Image.FromFile(OpenFileDialog1.FileName)
            Dim imagenstrem As System.IO.MemoryStream = New System.IO.MemoryStream

            myimagen.Save(imagenstrem, System.Drawing.Imaging.ImageFormat.Jpeg)
            imgbyte = imagenstrem.GetBuffer
        End If
    End Sub

    Private Sub OpenFileDialog1_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog1.FileOk
        txtimagen.ImageLocation = OpenFileDialog1.FileName
    End Sub
End Class