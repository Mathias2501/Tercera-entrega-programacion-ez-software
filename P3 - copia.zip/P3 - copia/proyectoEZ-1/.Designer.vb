﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Formalmacen
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Buttonatras = New System.Windows.Forms.Button()
        Me.txtdatagrid = New System.Windows.Forms.DataGridView()
        CType(Me.txtdatagrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Buttonatras
        '
        Me.Buttonatras.Image = Global.proyectoEZ_1.My.Resources.Resources._1231
        Me.Buttonatras.Location = New System.Drawing.Point(12, 12)
        Me.Buttonatras.Name = "Buttonatras"
        Me.Buttonatras.Size = New System.Drawing.Size(82, 66)
        Me.Buttonatras.TabIndex = 0
        Me.Buttonatras.UseVisualStyleBackColor = True
        '
        'txtdatagrid
        '
        Me.txtdatagrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.txtdatagrid.Location = New System.Drawing.Point(100, 12)
        Me.txtdatagrid.Name = "txtdatagrid"
        Me.txtdatagrid.Size = New System.Drawing.Size(465, 303)
        Me.txtdatagrid.TabIndex = 2
        '
        'Formalmacen
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(577, 332)
        Me.Controls.Add(Me.txtdatagrid)
        Me.Controls.Add(Me.Buttonatras)
        Me.Name = "Formalmacen"
        Me.Text = "almacen"
        CType(Me.txtdatagrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Buttonatras As Button
    Friend WithEvents txtdatagrid As DataGridView
End Class
