﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions
Public Class formregistro
    Private Sub Buttonatras_Click(sender As Object, e As EventArgs) Handles Buttonatras.Click
        formmenu.Show()
        Me.Hide()
    End Sub

    Private Sub Buttonregistrar_Click(sender As Object, e As EventArgs) Handles Buttonregistrar.Click
        Dim conexion As MySqlConnection
        conexion = New MySqlConnection
        Dim cmd As New MySqlCommand
        Dim par As String
        Dim rol As String
        conexion.ConnectionString = "server=localhost; database=mercado_lider;Uid=root;Pwd=;"
        If txtnombre.Text = "" Or txtapellido.Text = "" Or txtcalle.Text = "" Or txtciudad.Text = "" Or txtcontraseña.Text = "" Or txtdepartamento.Text = "" Or txtgmail.Text = "" Or txtnumerocasa.Text = "" Or TextBoxtelefono.Text = "" Then
            MsgBox("ingrese todos los datos")
        Else



            If txtvendedor.Checked = True Then
                rol = "3"
            ElseIf txtcomprador.Checked = True Then
                rol = "2"
            End If

            Try
                par = "^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$"
                If Me.ValidateChildren Or txtnombre.Text <> String.Empty Or txtapellido.Text <> String.Empty Or txtcalle.Text <> String.Empty Or txtciudad.Text <> String.Empty Or TextBoxtelefono.Text <> String.Empty Or txtdepartamento.Text <> String.Empty Or txtcontraseña.Text <> String.Empty Or txtnumerocasa.Text <> String.Empty Or txtvendedor.Text <> String.Empty And txtcomprador.Text <> String.Empty Or Regex.IsMatch(txtgmail.Text, par) Then
                    conexion.Open()
                    cmd.Connection = conexion
                    cmd.CommandText = "INSERT INTO usuarios(Nombre,Apellido,Pass,Email,Nombre_calle,Numero_calle,Departamento,Ciudad,ID_rol,telefono) VALUES(@nombre,@apellido,@contraseña,@gmail,@calle,@numerocasa,@departamento,@ciudad,@id_rol,@telefono)"
                    cmd.Prepare()
                    cmd.Parameters.AddWithValue("@nombre", txtnombre.Text)
                    cmd.Parameters.AddWithValue("@apellido", txtapellido.Text)
                    cmd.Parameters.AddWithValue("@contraseña", txtcontraseña.Text)
                    cmd.Parameters.AddWithValue("@gmail", txtgmail.Text)
                    cmd.Parameters.AddWithValue("@calle", txtcalle.Text)
                    cmd.Parameters.AddWithValue("@numerocasa", txtnumerocasa.Text)
                    cmd.Parameters.AddWithValue("@departamento", txtdepartamento.Text)
                    cmd.Parameters.AddWithValue("@ciudad", txtciudad.Text)
                    cmd.Parameters.AddWithValue("@id_rol", rol)
                    cmd.Parameters.AddWithValue("@telefono", TextBoxtelefono.Text)
                    cmd.ExecuteNonQuery()
                    If txtcomprador.Checked = True Then

                        Forminiciosesion.Show()
                        Me.Hide()

                    ElseIf txtvendedor.Checked = True Then


                        Forminiciosesion.Show()
                        Me.Hide()

                    End If

                End If
                conexion.Close()

            Catch ex As Exception
                MsgBox(ex.Message)

            End Try
        End If
    End Sub

    Private Sub TextBoxtelefono_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBoxtelefono.KeyPress
        e.Handled = Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar)
        If Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar) Then
            MsgBox("solo digite numeros")
        End If

    End Sub
End Class