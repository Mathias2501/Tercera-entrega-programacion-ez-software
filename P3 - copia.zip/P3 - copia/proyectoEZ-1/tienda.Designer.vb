﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Formtienda
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.txtdatagrid = New System.Windows.Forms.DataGridView()
        Me.buttonatras = New System.Windows.Forms.Button()
        Me.buttoncomprar = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtstock = New System.Windows.Forms.TextBox()
        Me.txtnombre = New System.Windows.Forms.TextBox()
        Me.txtprecio = New System.Windows.Forms.TextBox()
        Me.txtdesc = New System.Windows.Forms.TextBox()
        Me.descripcion = New System.Windows.Forms.Label()
        Me.txttiempo = New System.Windows.Forms.DateTimePicker()
        Me.txtidusu = New System.Windows.Forms.TextBox()
        CType(Me.txtdatagrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtdatagrid
        '
        Me.txtdatagrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.txtdatagrid.Location = New System.Drawing.Point(99, 12)
        Me.txtdatagrid.Name = "txtdatagrid"
        Me.txtdatagrid.Size = New System.Drawing.Size(463, 275)
        Me.txtdatagrid.TabIndex = 0
        '
        'buttonatras
        '
        Me.buttonatras.Image = Global.proyectoEZ_1.My.Resources.Resources._1231
        Me.buttonatras.Location = New System.Drawing.Point(12, 12)
        Me.buttonatras.Name = "buttonatras"
        Me.buttonatras.Size = New System.Drawing.Size(75, 68)
        Me.buttonatras.TabIndex = 1
        Me.buttonatras.UseVisualStyleBackColor = True
        '
        'buttoncomprar
        '
        Me.buttoncomprar.Location = New System.Drawing.Point(426, 296)
        Me.buttoncomprar.Name = "buttoncomprar"
        Me.buttoncomprar.Size = New System.Drawing.Size(136, 137)
        Me.buttoncomprar.TabIndex = 2
        Me.buttoncomprar.Text = "comprar"
        Me.buttoncomprar.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(216, 296)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(104, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "nombre del producto"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(281, 325)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(33, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "stock"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(278, 358)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(36, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "precio"
        '
        'txtstock
        '
        Me.txtstock.Location = New System.Drawing.Point(320, 325)
        Me.txtstock.Name = "txtstock"
        Me.txtstock.Size = New System.Drawing.Size(100, 20)
        Me.txtstock.TabIndex = 6
        '
        'txtnombre
        '
        Me.txtnombre.Location = New System.Drawing.Point(320, 299)
        Me.txtnombre.Name = "txtnombre"
        Me.txtnombre.Size = New System.Drawing.Size(100, 20)
        Me.txtnombre.TabIndex = 7
        '
        'txtprecio
        '
        Me.txtprecio.Location = New System.Drawing.Point(320, 358)
        Me.txtprecio.Name = "txtprecio"
        Me.txtprecio.Size = New System.Drawing.Size(100, 20)
        Me.txtprecio.TabIndex = 8
        '
        'txtdesc
        '
        Me.txtdesc.Location = New System.Drawing.Point(320, 386)
        Me.txtdesc.Multiline = True
        Me.txtdesc.Name = "txtdesc"
        Me.txtdesc.Size = New System.Drawing.Size(100, 47)
        Me.txtdesc.TabIndex = 10
        '
        'descripcion
        '
        Me.descripcion.AutoSize = True
        Me.descripcion.Location = New System.Drawing.Point(253, 386)
        Me.descripcion.Name = "descripcion"
        Me.descripcion.Size = New System.Drawing.Size(61, 13)
        Me.descripcion.TabIndex = 9
        Me.descripcion.Text = "descripcion"
        '
        'txttiempo
        '
        Me.txttiempo.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txttiempo.Location = New System.Drawing.Point(99, 296)
        Me.txttiempo.Name = "txttiempo"
        Me.txttiempo.Size = New System.Drawing.Size(111, 20)
        Me.txttiempo.TabIndex = 11
        '
        'txtidusu
        '
        Me.txtidusu.Location = New System.Drawing.Point(12, 86)
        Me.txtidusu.Name = "txtidusu"
        Me.txtidusu.Size = New System.Drawing.Size(75, 20)
        Me.txtidusu.TabIndex = 12
        '
        'Formtienda
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(574, 442)
        Me.Controls.Add(Me.txtidusu)
        Me.Controls.Add(Me.txttiempo)
        Me.Controls.Add(Me.txtdesc)
        Me.Controls.Add(Me.descripcion)
        Me.Controls.Add(Me.txtprecio)
        Me.Controls.Add(Me.txtnombre)
        Me.Controls.Add(Me.txtstock)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.buttoncomprar)
        Me.Controls.Add(Me.buttonatras)
        Me.Controls.Add(Me.txtdatagrid)
        Me.Name = "Formtienda"
        Me.Text = "tienda"
        CType(Me.txtdatagrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtdatagrid As DataGridView
    Friend WithEvents buttonatras As Button
    Friend WithEvents buttoncomprar As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtstock As TextBox
    Friend WithEvents txtnombre As TextBox
    Friend WithEvents txtprecio As TextBox
    Friend WithEvents txtdesc As TextBox
    Friend WithEvents descripcion As Label
    Friend WithEvents txttiempo As DateTimePicker
    Friend WithEvents txtidusu As TextBox
End Class
