﻿Imports MySql.Data.MySqlClient
Public Class Formtienda
    Dim conexion As New MySqlConnection
    Dim cmd As New MySqlCommand

    Private Sub Buttonatras_Click(sender As Object, e As EventArgs) Handles Buttonatras.Click
        Forminiciosesion.Show()
        Me.Hide()
    End Sub

    Private Sub Formtienda_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        datagrid()
        Dim sql As String
        sql = "SELECT nombre_producto,stock,descripcion,precio FROM productos"
        llenardatagrid(txtdatagrid, sql)
        txtidusu.Text = funcion1.idusu1
    End Sub

    Private Sub Buttoncomprar_Click(sender As Object, e As EventArgs) Handles buttoncomprar.Click
        conexion.ConnectionString = "server=localhost; database=mercado_lider;Uid=root;Pwd=;"
        If txtnombre.Text <> String.Empty Or txtstock.Text <> String.Empty Or txtdesc.Text <> String.Empty Or txtprecio.Text <> String.Empty Then
            conexion.Open()
            cmd.Connection = conexion
            cmd.CommandText = "INSERT INTO pedidos(ID_pedido,Fecha,ID_usuario) values ('null','@nombreproducto','@precio')"
            cmd.Prepare()
            cmd.Parameters.AddWithValue("@tiempo", txttiempo.Text)
            cmd.Parameters.AddWithValue("@idusu", txtidusu.Text)
            cmd.ExecuteNonQuery()
            conexion.Close()
        Else
            MsgBox("ingrese todos los datos")
        End If
    End Sub

    Private Sub txtdatagrid_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles txtdatagrid.CellContentClick

    End Sub

    Private Sub txtdatagrid_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles txtdatagrid.CellClick
        If e.ColumnIndex >= 0 AndAlso e.RowIndex >= 0 Then
            txtnombre = txtdatagrid.Rows(e.RowIndex).Cells(0).Value
            txtstock = txtdatagrid.Rows(e.RowIndex).Cells(1).Value
            txtdesc = txtdatagrid.Rows(e.RowIndex).Cells(2).Value
            txtprecio = txtdatagrid.Rows(e.RowIndex).Cells(3).Value
        End If
    End Sub
End Class
