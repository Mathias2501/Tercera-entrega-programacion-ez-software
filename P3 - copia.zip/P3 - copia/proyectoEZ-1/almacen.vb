﻿Imports MySql.Data.MySqlClient
Public Class Formalmacen
    Dim conexion As New MySqlConnection
    Dim cmd As New MySqlCommand
    Private Sub Buttonatras_Click(sender As Object, e As EventArgs) Handles Buttonatras.Click
        Formmenuadmin.Show()
        Me.Hide()
    End Sub

    Private Sub Formalmacen_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        datagrid()
        Dim sql As String
        sql = "SELECT * FROM productos"
        llenardatagrid(txtdatagrid, sql)
    End Sub
End Class



