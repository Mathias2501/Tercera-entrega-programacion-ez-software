﻿Imports MySql.Data.MySqlClient
Public Class Formlistacliente


    Private Sub Buttonatras_Click(sender As Object, e As EventArgs) Handles Buttonatras.Click
        Formmenuadmin.Show()
        Me.Hide()
    End Sub

    Private Sub Formlistacliente_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        datagrid()
        Dim sql As String
        sql = "SELECT * FROM usuarios"
        llenardatagrid(txtdatagrid, sql)
    End Sub
End Class