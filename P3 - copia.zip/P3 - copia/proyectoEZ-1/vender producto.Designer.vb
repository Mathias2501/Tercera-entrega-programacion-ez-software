﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formvenderproducto
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtimagen = New System.Windows.Forms.PictureBox()
        Me.txtbuscar = New System.Windows.Forms.Button()
        Me.txtdatagrid = New System.Windows.Forms.DataGridView()
        Me.txtnombreproducto = New System.Windows.Forms.TextBox()
        Me.txtprecio = New System.Windows.Forms.TextBox()
        Me.txtcantidad = New System.Windows.Forms.TextBox()
        Me.txtdescripcion = New System.Windows.Forms.TextBox()
        Me.txtidusu = New System.Windows.Forms.TextBox()
        Me.Buttonatras = New System.Windows.Forms.Button()
        Me.Buttonvender = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtComBox = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        CType(Me.txtimagen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdatagrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtimagen
        '
        Me.txtimagen.Location = New System.Drawing.Point(462, 12)
        Me.txtimagen.Name = "txtimagen"
        Me.txtimagen.Size = New System.Drawing.Size(251, 180)
        Me.txtimagen.TabIndex = 0
        Me.txtimagen.TabStop = False
        '
        'txtbuscar
        '
        Me.txtbuscar.Location = New System.Drawing.Point(506, 207)
        Me.txtbuscar.Name = "txtbuscar"
        Me.txtbuscar.Size = New System.Drawing.Size(172, 68)
        Me.txtbuscar.TabIndex = 1
        Me.txtbuscar.Text = "buscar imagen"
        Me.txtbuscar.UseVisualStyleBackColor = True
        '
        'txtdatagrid
        '
        Me.txtdatagrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.txtdatagrid.Location = New System.Drawing.Point(12, 296)
        Me.txtdatagrid.Name = "txtdatagrid"
        Me.txtdatagrid.Size = New System.Drawing.Size(701, 226)
        Me.txtdatagrid.TabIndex = 2
        '
        'txtnombreproducto
        '
        Me.txtnombreproducto.Location = New System.Drawing.Point(297, 13)
        Me.txtnombreproducto.Name = "txtnombreproducto"
        Me.txtnombreproducto.Size = New System.Drawing.Size(136, 20)
        Me.txtnombreproducto.TabIndex = 3
        '
        'txtprecio
        '
        Me.txtprecio.Location = New System.Drawing.Point(297, 49)
        Me.txtprecio.Name = "txtprecio"
        Me.txtprecio.Size = New System.Drawing.Size(136, 20)
        Me.txtprecio.TabIndex = 4
        '
        'txtcantidad
        '
        Me.txtcantidad.Location = New System.Drawing.Point(297, 84)
        Me.txtcantidad.Name = "txtcantidad"
        Me.txtcantidad.Size = New System.Drawing.Size(136, 20)
        Me.txtcantidad.TabIndex = 5
        '
        'txtdescripcion
        '
        Me.txtdescripcion.Location = New System.Drawing.Point(297, 119)
        Me.txtdescripcion.Multiline = True
        Me.txtdescripcion.Name = "txtdescripcion"
        Me.txtdescripcion.Size = New System.Drawing.Size(136, 55)
        Me.txtdescripcion.TabIndex = 6
        '
        'txtidusu
        '
        Me.txtidusu.Location = New System.Drawing.Point(12, 270)
        Me.txtidusu.Name = "txtidusu"
        Me.txtidusu.Size = New System.Drawing.Size(124, 20)
        Me.txtidusu.TabIndex = 7
        Me.txtidusu.Visible = False
        '
        'Buttonatras
        '
        Me.Buttonatras.Image = Global.proyectoEZ_1.My.Resources.Resources._1231
        Me.Buttonatras.Location = New System.Drawing.Point(12, 12)
        Me.Buttonatras.Name = "Buttonatras"
        Me.Buttonatras.Size = New System.Drawing.Size(87, 72)
        Me.Buttonatras.TabIndex = 9
        Me.Buttonatras.UseVisualStyleBackColor = True
        '
        'Buttonvender
        '
        Me.Buttonvender.Location = New System.Drawing.Point(12, 125)
        Me.Buttonvender.Name = "Buttonvender"
        Me.Buttonvender.Size = New System.Drawing.Size(115, 86)
        Me.Buttonvender.TabIndex = 10
        Me.Buttonvender.Text = "ingresar producto"
        Me.Buttonvender.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(171, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(104, 13)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "nombre del producto"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(214, 49)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(36, 13)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "precio"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(214, 84)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 13)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "cantidad"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(214, 122)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(61, 13)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "descripción"
        '
        'txtComBox
        '
        Me.txtComBox.FormattingEnabled = True
        Me.txtComBox.Location = New System.Drawing.Point(297, 198)
        Me.txtComBox.Name = "txtComBox"
        Me.txtComBox.Size = New System.Drawing.Size(136, 21)
        Me.txtComBox.TabIndex = 15
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(214, 198)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(56, 13)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "categorias"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'formvenderproducto
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(725, 534)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtComBox)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Buttonvender)
        Me.Controls.Add(Me.Buttonatras)
        Me.Controls.Add(Me.txtidusu)
        Me.Controls.Add(Me.txtdescripcion)
        Me.Controls.Add(Me.txtcantidad)
        Me.Controls.Add(Me.txtprecio)
        Me.Controls.Add(Me.txtnombreproducto)
        Me.Controls.Add(Me.txtdatagrid)
        Me.Controls.Add(Me.txtbuscar)
        Me.Controls.Add(Me.txtimagen)
        Me.Name = "formvenderproducto"
        Me.Text = "vender_producto"
        CType(Me.txtimagen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdatagrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtimagen As PictureBox
    Friend WithEvents txtbuscar As Button
    Friend WithEvents txtdatagrid As DataGridView
    Friend WithEvents txtnombreproducto As TextBox
    Friend WithEvents txtprecio As TextBox
    Friend WithEvents txtcantidad As TextBox
    Friend WithEvents txtdescripcion As TextBox
    Friend WithEvents txtidusu As TextBox
    Friend WithEvents Buttonatras As Button
    Friend WithEvents Buttonvender As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtComBox As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
End Class
