﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formregistro
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Buttonatras = New System.Windows.Forms.Button()
        Me.Buttonregistrar = New System.Windows.Forms.Button()
        Me.txtnombre = New System.Windows.Forms.TextBox()
        Me.txtgmail = New System.Windows.Forms.TextBox()
        Me.TextBoxtelefono = New System.Windows.Forms.TextBox()
        Me.txtcontraseña = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtcalle = New System.Windows.Forms.TextBox()
        Me.txtdepartamento = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtnumerocasa = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtciudad = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtapellido = New System.Windows.Forms.TextBox()
        Me.txtvendedor = New System.Windows.Forms.RadioButton()
        Me.txtcomprador = New System.Windows.Forms.RadioButton()
        Me.SuspendLayout()
        '
        'Buttonatras
        '
        Me.Buttonatras.Image = Global.proyectoEZ_1.My.Resources.Resources._1231
        Me.Buttonatras.Location = New System.Drawing.Point(12, 12)
        Me.Buttonatras.Name = "Buttonatras"
        Me.Buttonatras.Size = New System.Drawing.Size(70, 65)
        Me.Buttonatras.TabIndex = 0
        Me.Buttonatras.UseVisualStyleBackColor = True
        '
        'Buttonregistrar
        '
        Me.Buttonregistrar.Location = New System.Drawing.Point(116, 550)
        Me.Buttonregistrar.Name = "Buttonregistrar"
        Me.Buttonregistrar.Size = New System.Drawing.Size(148, 62)
        Me.Buttonregistrar.TabIndex = 1
        Me.Buttonregistrar.Text = "registrar"
        Me.Buttonregistrar.UseVisualStyleBackColor = True
        '
        'txtnombre
        '
        Me.txtnombre.Location = New System.Drawing.Point(164, 139)
        Me.txtnombre.Name = "txtnombre"
        Me.txtnombre.Size = New System.Drawing.Size(133, 20)
        Me.txtnombre.TabIndex = 2
        '
        'txtgmail
        '
        Me.txtgmail.Location = New System.Drawing.Point(164, 210)
        Me.txtgmail.Name = "txtgmail"
        Me.txtgmail.Size = New System.Drawing.Size(133, 20)
        Me.txtgmail.TabIndex = 4
        '
        'TextBoxtelefono
        '
        Me.TextBoxtelefono.Location = New System.Drawing.Point(163, 257)
        Me.TextBoxtelefono.Name = "TextBoxtelefono"
        Me.TextBoxtelefono.Size = New System.Drawing.Size(133, 20)
        Me.TextBoxtelefono.TabIndex = 5
        '
        'txtcontraseña
        '
        Me.txtcontraseña.AccessibleName = "*"
        Me.txtcontraseña.Location = New System.Drawing.Point(163, 298)
        Me.txtcontraseña.Name = "txtcontraseña"
        Me.txtcontraseña.Size = New System.Drawing.Size(133, 20)
        Me.txtcontraseña.TabIndex = 6
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(81, 145)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "nombre"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(80, 212)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(31, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "gmail"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(80, 257)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(45, 13)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "teléfono"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(80, 298)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "contraseña"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(160, 338)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 13)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "Dirección"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(80, 376)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(29, 13)
        Me.Label6.TabIndex = 16
        Me.Label6.Text = "calle"
        '
        'txtcalle
        '
        Me.txtcalle.Location = New System.Drawing.Point(163, 376)
        Me.txtcalle.Name = "txtcalle"
        Me.txtcalle.Size = New System.Drawing.Size(133, 20)
        Me.txtcalle.TabIndex = 17
        '
        'txtdepartamento
        '
        Me.txtdepartamento.Location = New System.Drawing.Point(164, 410)
        Me.txtdepartamento.Name = "txtdepartamento"
        Me.txtdepartamento.Size = New System.Drawing.Size(133, 20)
        Me.txtdepartamento.TabIndex = 18
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(58, 444)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(94, 13)
        Me.Label7.TabIndex = 19
        Me.Label7.Text = "numero de la casa"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(80, 410)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(72, 13)
        Me.Label8.TabIndex = 20
        Me.Label8.Text = "departamento"
        '
        'txtnumerocasa
        '
        Me.txtnumerocasa.Location = New System.Drawing.Point(163, 444)
        Me.txtnumerocasa.Name = "txtnumerocasa"
        Me.txtnumerocasa.Size = New System.Drawing.Size(133, 20)
        Me.txtnumerocasa.TabIndex = 21
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(82, 472)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(39, 13)
        Me.Label9.TabIndex = 22
        Me.Label9.Text = "ciudad"
        '
        'txtciudad
        '
        Me.txtciudad.Location = New System.Drawing.Point(163, 472)
        Me.txtciudad.Name = "txtciudad"
        Me.txtciudad.Size = New System.Drawing.Size(133, 20)
        Me.txtciudad.TabIndex = 23
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(83, 176)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(43, 13)
        Me.Label10.TabIndex = 24
        Me.Label10.Text = "apellido"
        '
        'txtapellido
        '
        Me.txtapellido.Location = New System.Drawing.Point(163, 173)
        Me.txtapellido.Name = "txtapellido"
        Me.txtapellido.Size = New System.Drawing.Size(133, 20)
        Me.txtapellido.TabIndex = 25
        '
        'txtvendedor
        '
        Me.txtvendedor.AutoSize = True
        Me.txtvendedor.Location = New System.Drawing.Point(229, 514)
        Me.txtvendedor.Name = "txtvendedor"
        Me.txtvendedor.Size = New System.Drawing.Size(70, 17)
        Me.txtvendedor.TabIndex = 26
        Me.txtvendedor.TabStop = True
        Me.txtvendedor.Text = "vendedor"
        Me.txtvendedor.UseVisualStyleBackColor = True
        '
        'txtcomprador
        '
        Me.txtcomprador.AutoSize = True
        Me.txtcomprador.Location = New System.Drawing.Point(86, 514)
        Me.txtcomprador.Name = "txtcomprador"
        Me.txtcomprador.Size = New System.Drawing.Size(75, 17)
        Me.txtcomprador.TabIndex = 27
        Me.txtcomprador.TabStop = True
        Me.txtcomprador.Text = "comprador"
        Me.txtcomprador.UseVisualStyleBackColor = True
        '
        'formregistro
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(370, 651)
        Me.Controls.Add(Me.txtcomprador)
        Me.Controls.Add(Me.txtvendedor)
        Me.Controls.Add(Me.txtapellido)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txtciudad)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtnumerocasa)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtdepartamento)
        Me.Controls.Add(Me.txtcalle)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtcontraseña)
        Me.Controls.Add(Me.TextBoxtelefono)
        Me.Controls.Add(Me.txtgmail)
        Me.Controls.Add(Me.txtnombre)
        Me.Controls.Add(Me.Buttonregistrar)
        Me.Controls.Add(Me.Buttonatras)
        Me.Name = "formregistro"
        Me.Text = "registrarse"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Buttonatras As Button
    Friend WithEvents Buttonregistrar As Button
    Friend WithEvents txtnombre As TextBox
    Friend WithEvents txtgmail As TextBox
    Friend WithEvents TextBoxtelefono As TextBox
    Friend WithEvents txtcontraseña As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtcalle As TextBox
    Friend WithEvents txtdepartamento As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents txtnumerocasa As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents txtciudad As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txtapellido As TextBox
    Friend WithEvents txtvendedor As RadioButton
    Friend WithEvents txtcomprador As RadioButton
End Class
